SELECT 
    c.ID as Cust_ID,
    c.Name as Cust_Name,
    s.ID as Salesperson_ID,
    s.Name as Salesperson_Name,
    o.Amount as Max_Amount
FROM 
    Orders o
JOIN 
    Customer c ON o.cust_id = c.ID
JOIN 
    Salesperson s ON o.salesperson_id = s.ID
WHERE 
    o.Amount = (
        SELECT MAX(Amount) 
        FROM Orders
    );


Customer table 
ID - primary key 

Salesperson table 
ID - primary key

Orders table:

order_id (primary key)
cust_id (foreign key referencing customers)
salesperson_id (foreign key referencing salespersons)
order_amount



Explanation of the query:
JOIN Clauses: We join the orders table with customer and salesperson tables using their respective foreign keys (cust_id and salesperson_id).

SELECT Clause: We select columns ID and Name from Customer, ID and Name from salesperson, and order_amount from orders.

WHERE Clause: The WHERE clause filters rows to find the highest order_amount for each combination of cust_id and salesperson_id. It uses a subquery to select the maximum order_amount for each (cust_id, salesperson_id) pair.

Subquery Explanation: The subquery (SELECT MAX(order_amount) FROM orders WHERE c.ID = o.cust_id AND s.ID = o.salesperson_id) finds the maximum order_amount for each specific customer-salesperson combination.

This query will return the rows with the highest order_amount for each customer-salesperson combination, along with the specified columns (c.ID, c.Name, s.ID, s.Name, order_amount). 