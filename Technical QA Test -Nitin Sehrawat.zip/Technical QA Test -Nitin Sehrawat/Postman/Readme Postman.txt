Step-by-Step Guide how to execute the tests.

1. Open Postman and import the the collection ------ attached in the zip folder

2. Click on the "Send" button to send the GET request to the API endpoint.

3. Validate the Response:

Postman will display the response received from the API in the "Body" tab.

Verify that the response contains the expected data (list of countries).

4. To execute the automation, go to your collection, click on the "Run" button.
Postman will execute the request and run the tests automatically.

5. Review Results:
Postman will display the results of each test case in the "Tests" tab and indicate if they pass or fail.
If all tests pass, it confirms that the API response meets your expected criteria.

We can use environment variables to manage dynamic data like API keys or base URLs.
We can iterate test if the API returns paginated results or you need to test different scenarios, consider using Postman's collection runner with data files.

By following these steps, you can effectively automate the process of sending a GET request to an API endpoint and validating its response using Postman, ensuring reliable and repeatable testing of your API interactions.